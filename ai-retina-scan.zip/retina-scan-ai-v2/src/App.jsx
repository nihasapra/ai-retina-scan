import RetinaScanMVP_Advanced from './RetinaScanMVP_Advanced';

function App() {
  return <RetinaScanMVP_Advanced />;
}

export default App;
