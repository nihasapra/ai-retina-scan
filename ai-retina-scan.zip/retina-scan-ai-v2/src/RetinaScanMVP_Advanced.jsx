// Paste your RetinaScanMVP_Advanced component code here
